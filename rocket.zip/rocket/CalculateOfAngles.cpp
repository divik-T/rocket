﻿#include "CalculateOfAngles.h"
#include "Enviroment.h"


double p0 = (PI / 180) * 10,
q0 = (PI / 180) * 100,
r0 = (PI / 180) * 10;
// Поворот вектора из локальной в лабораторную систему
Vec3 rotateVectorByQuaternion(const Vec3& v, const Quaternion& q) {
    // Представление вектора как кватерниона с нулевой компонентой w
    Quaternion vectorQuat = { 0.0, v.x, v.y, v.z };

    // Переворот (конъюгация кватерниона)
    Quaternion qConjugate = { q.w, -q.x, -q.y, -q.z };

    // Применение вращения через кватернион
    Quaternion resultQuat = multiply(multiply(q, vectorQuat), qConjugate);

    // Возвращаем результат как новый вектор
    return { resultQuat.x, resultQuat.y, resultQuat.z };
}

// Обратное преобразование из лабораторной в локальную
Vec3 rotateEulerLocalToLab(const Vec3& v, double phi, double theta, double psi) {
    // Создаем кватернионы для каждого из вращений
    Quaternion q1 = createRotationQuaternionZ(phi);    // Поворот вокруг Z
    Quaternion q2 = createRotationQuaternionX(theta);  // Поворот вокруг X'
    Quaternion q3 = createRotationQuaternionZ(psi);    // Поворот вокруг Z''

    // Умножаем кватернионы в правильном порядке
    Quaternion q = multiply(multiply(q1, q2), q3);

    // Нормализуем результат, чтобы избежать ошибок из-за числовых погрешностей
    q.normalize();

    // Применяем полученный кватернион к вектору
    return rotateVectorByQuaternion(v, q);
}

Vec3 rotateEulerLabToLocal(const Vec3& v, double phi, double theta, double psi) {
    Quaternion q1 = createRotationQuaternionZ(phi);    // Z (φ)
    Quaternion q2 = createRotationQuaternionX(theta);  // X' (θ)
    Quaternion q3 = createRotationQuaternionZ(psi);    // Z'' (ψ)

    Quaternion q = multiply(multiply(q3, q2), q1); // Порядок Z''→X'→Z
    q.normalize();

    Quaternion qConj = conjugate(q);
    return rotateVectorByQuaternion(v, qConj);
}

std::map<std::pair<double, double>, Vec3> splitCylinderNormals(double R, double H, double dH, double dGama) {
    std::map<std::pair<double, double>, Vec3> normalMap;
    for (int z = -H / 2; z <= H / 2; z += dH) {
        double centerZ = z + (dH / 2);// Координата Z центра сегмента
        for (int gama = 0; gama < 2 * PI; gama += dGama) {
            double centerGama = gama + (dGama / 2); // Координата gama центра сегмента
            const Vec3 normal = {
                std::cos(centerGama),
                std::sin(centerGama),
                0.0
            };
            normalMap[{centerGama, centerZ}] = normal;
        }
    }
    return normalMap;
}

Vec3 calculateMomentOfResistance(std::map<std::pair<double, double>, Vec3> normalMap, double resistanceCoeff, const Vec3& velocity, double R, double dS) {
    Vec3 resultM = { 0,0,0 };
    for (auto it = normalMap.begin(); it != normalMap.end(); ++it) {
        const std::pair<double, double>& coordinates = it->first;
        const Vec3& normal = it->second;
        double gama = coordinates.first;
        double z = coordinates.second;

        Vec3 radiusVector = { R * cos(gama),R * sin(gama),z };
        double velocityModule = velocity.module();
        double angleVelNormal = velocity.calcAngle(normal);
        Vec3 perpForceDirection = { cos(gama),sin(gama),0 };
        double dMModule = resistanceCoeff * dS * velocityModule * velocityModule * sin(angleVelNormal) * sin(angleVelNormal);
        Vec3 dM = dMModule * (radiusVector.CrossMult(perpForceDirection));
        resultM += dM;
    }
    return resultM;
}

std::map<Vec3, double> createCoordPercOfOpenSoplesMap(double R, std::vector<double> PercOfOpenSoples) {
    std::map<Vec3, double> coordPercOfOpenSoplesMap;
    coordPercOfOpenSoplesMap[{3 * R / 4, 0, 0}] = PercOfOpenSoples[0];
    coordPercOfOpenSoplesMap[{-3 * R / 4, 0, 0}] = PercOfOpenSoples[1];
    coordPercOfOpenSoplesMap[{0, 3 * R / 4, 0}] = PercOfOpenSoples[2];
    coordPercOfOpenSoplesMap[{0, -3 * R / 4, 0}] = PercOfOpenSoples[3];
    return coordPercOfOpenSoplesMap;
}

Vec3 calculateMomentOfSoples(std::map<Vec3, double> coordPercOfOpenSoplesMap, double thrustForceAll) {
    Vec3 resultM = { 0,0,0 };
    for (auto it = coordPercOfOpenSoplesMap.begin(); it != coordPercOfOpenSoplesMap.end(); ++it) {
        const Vec3& radiusVec = it->first;
        double PercOfOpenSople = it->second;
        Vec3 thrustForceDir = { 0,0,1 };
        double thrustForceModule = 0.25 * thrustForceAll * PercOfOpenSople;
        Vec3 thrustForce = thrustForceModule * thrustForceDir;
        Vec3 thrustForceMoment = radiusVec.CrossMult(thrustForce);
        resultM += thrustForceMoment;
    }
    return resultM;
}

std::vector<double> RotationdMotion::calcPercOfOpenSoples() const {
    Vec3 tau;
    tau.x = x - x0;
    tau.y = y - y0;
    tau.z = z - z0;
    tau.normalize();
    obj.convertVectorLabToLocal(tau);
    std::vector<double> PercOfOpenSoples;
    PercOfOpenSoples.push_back(1 - tau.x);
    PercOfOpenSoples.push_back(1 + tau.x);
    PercOfOpenSoples.push_back(1 - tau.y);
    PercOfOpenSoples.push_back(1 + tau.y);
    return  PercOfOpenSoples;
}

double safeSin(double angle) {
    double s = sin(angle);
    if (fabs(s) < 1e-6) return (s >= 0 ? 1e-6 : -1e-6);
    return s;
}

double normalizePhiPsi(double angle) {
    if (angle < 0) {
        while (angle < 0) {
            angle += 2 * PI;
        }
    }
    if (angle > 2 * PI) {
        while (angle > 2 * PI) {
            angle -= 2 * PI;
        }
    }
    return angle;
}

std::vector<double> analyticalSolution(const FlyingObject obj, double t) {


    double omega = ((obj.Jp - obj.Jr) / obj.Jp) * r0;

    // Решение
    double p = q0 * sin(omega * t) + p0 * cos(omega * t);
    double q = q0 * cos(omega * t) - p0 * sin(omega * t);
    double r = r0;

    return { p, q, r };
}