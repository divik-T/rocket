#pragma once
#include <vector>
#include "FlyingObject.h"

int OrderOfRK = 4;
const int numOfParam = 7;
double bRK(int i);

double cRK(int i);

void oneStepRungeKutt(
    const std::vector<double>& vecOfLeftParts,
    std::vector<double>& vecOfNewLeftParts,
    const std::vector<double(*)(const std::vector<double>& phaseSpace, const FlyingObject& obj, const Enviroment& env)>& vecOfRightParts,
    const FlyingObject& obj,
    const Enviroment& env,
    double t, double dt);

double EulerEqP(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env);

double EulerEqQ(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env);

double EulerEqR(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env);

double convertLocalToEulerPhi(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env);

double convertLocalToEulerPsi(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env);

double convertLocalToEulerTeta(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env);

void updateState(std::vector<double>& vecOfNewLeftParts,
    FlyingObject& obj,
    Enviroment& env,
    double t, double dt);

void CalculationOfTrajectory(FlyingObject& obj, Enviroment& env, double& t, double dt, std::ofstream& file);