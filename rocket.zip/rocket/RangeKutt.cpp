#include "RangeKutt.h"
#include <iostream>
int OrderOfRK = 4;

double bRK(int i) {
    switch (i) {
    case 0:
        return 1.0 / 6;
        break;
    case 1:
        return 2.0 / 6;
        break;
    case 2:
        return 2.0 / 6;
        break;
    case 3:
        return 1.0 / 6;
        break;
    }
}

double cRK(int i) {
    switch (i) {
    case 0:
        return 0.5;
        break;
    case 1:
        return 0.5;
        break;
    case 2:
        return 1;
        break;
    case 3:
        return 1.0;
        break;
    }
}

void oneStepRungeKutt(
    const std::vector<double>& vecOfLeftParts,
    std::vector<double>& vecOfNewLeftParts,
    const std::vector<double(*)(const std::vector<double>& phaseSpace, const FlyingObject& obj, const Enviroment& env)>& vecOfRightParts,
    const FlyingObject& obj,
    const Enviroment& env,
    double t, double dt) {

    std::vector <double> stateVector(vecOfNewLeftParts.size());
    std::vector <double> initialStateVector;
    std::copy(vecOfLeftParts.begin(), vecOfLeftParts.end(), stateVector.begin());
    std::copy(stateVector.begin(), stateVector.end(), vecOfNewLeftParts.begin());
    stateVector[stateVector.size() - 1] = t;
    initialStateVector = stateVector;
    std::vector<double> vecOfDeltaParam(stateVector.size());
    vecOfDeltaParam[vecOfDeltaParam.size() - 1] = dt;

    for (int j = 0; j < OrderOfRK; ++j) {
        for (int i = 0; i < vecOfDeltaParam.size() - 1; ++i) {
            vecOfDeltaParam[i] = dt * vecOfRightParts[i](stateVector, obj, env);
        }

        for (int i = 0; i < vecOfNewLeftParts.size(); ++i) {
            vecOfNewLeftParts[i] += vecOfDeltaParam[i] * bRK(j);
            stateVector[i] = initialStateVector[i] + cRK(j) * vecOfDeltaParam[i];
        }
    }
}

double EulerEqP(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env) {
    double
        p = stateVector[0],
        q = stateVector[1],
        r = stateVector[2];

    return (env.Mp / obj.Jp - ((obj.Jr - obj.Jq) / obj.Jp) * q * r);
}

// ������ ����� ������������� ��������� ������ �� ��� Q
double EulerEqQ(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env) {
    double
        p = stateVector[0],
        q = stateVector[1],
        r = stateVector[2];

    return (env.Mq / obj.Jq - ((obj.Jp - obj.Jr) / obj.Jq) * p * r);
}

// ������ ����� ������������� ��������� ������ �� ��� R
double EulerEqR(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env) {
    double
        p = stateVector[0],
        q = stateVector[1],
        r = stateVector[2];

    return (env.Mr / obj.Jr - ((obj.Jq - obj.Jp) / obj.Jr) * p * q);
}

// ������ ����� ��� ���� Phi
double convertLocalToEulerPhi(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env) {
    double p = stateVector[0],
        q = stateVector[1],
        r = stateVector[2],
        phi = stateVector[3],
        psi = stateVector[4],
        teta = stateVector[5];
    double result = (p * sin(psi) + cos(psi) * q) / safeSin(teta);
    return result;
}

// ������ ����� ��� ���� Psi
double convertLocalToEulerPsi(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env) {
    double p = stateVector[0],
        q = stateVector[1],
        r = stateVector[2],
        phi = stateVector[3],
        psi = stateVector[4],
        teta = stateVector[5];
    double result = r - (sin(psi) * p + cos(psi) * q) * cos(teta) / safeSin(teta);
    return result;
}

// ������ ����� ��� ���� Tetta
double convertLocalToEulerTeta(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env) {
    double p = stateVector[0],
        q = stateVector[1],
        r = stateVector[2],
        phi = stateVector[3],
        psi = stateVector[4],
        teta = stateVector[5];

    double result = (cos(psi) * p - sin(psi) * q);
    return result;
}

void updateState(std::vector<double>& vecOfNewLeftParts,
    FlyingObject& obj,
    Enviroment& env,
    double t, double dt) {
    obj.p = vecOfNewLeftParts[0];
    obj.q = vecOfNewLeftParts[1];
    obj.r = vecOfNewLeftParts[2];
    obj.phi = vecOfNewLeftParts[3];
    obj.psi = vecOfNewLeftParts[4];
    obj.teta = vecOfNewLeftParts[5];
}

void CalculationOfTrajectory(FlyingObject& obj, Enviroment& env, double& t, double dt, std::ofstream& file) {
    std::vector<double>newState(numOfParam);
    std::vector<double>State = { obj.p, obj.q, obj.r, obj.phi, obj.psi, obj.teta };
    std::vector<double(*)(const std::vector<double>& stateVector, const FlyingObject& obj, const Enviroment& env)> vecOfFunctions =
    { EulerEqP, EulerEqQ, EulerEqR, convertLocalToEulerPhi, convertLocalToEulerPsi, convertLocalToEulerTeta };
    std::vector<double>Solution(3);
    while (t < 10) {
        oneStepRungeKutt(State, newState, vecOfFunctions, obj, env, t, dt);
        updateState(newState, obj, env, t, dt);
        State = newState;
        t += dt;
        if (std::isnan(obj.phi) || std::isnan(obj.teta) || std::isnan(obj.psi)) {
            std::cerr << "NaN detected at t = " << t << std::endl;
            break;
        }

        WriteInFile(obj, t, file, Solution);
    }
    std::cout << "complete";
}